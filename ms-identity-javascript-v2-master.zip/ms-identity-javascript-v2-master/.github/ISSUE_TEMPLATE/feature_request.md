---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: derisen

---

Please follow the issue template below. Failure to do so will result in a delay in answering your question.

## Library

- [ ] `msal@2.x.x` or `@azure/msal@2.x.x`

## Description
